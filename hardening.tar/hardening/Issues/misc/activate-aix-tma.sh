#!/bin/sh
#
# This script is used to activate a pre-loaded Tivoli Management
# Agent on an IBM server running AIX 5.1L.
#
# The gateway IP address should be passed as argument 1.
# For String 3 the gateway is UNWG001887
# The gateway Port number should be passed as argument 2.
# For String 3 the port is 9190
# 
# add /usr/sbin to path for AIX to find mkitab
PATH=$PATH:/usr/sbin
GATEWAY=${1:-UNWG001887}
GWPORT=${2:-9190}

echo "Performing auto start configuration"

ETRC=/opt/Tivoli/lcf/dat/1/lcfd.sh
DEVNULL=/dev/null
DATE=`date`

#################
# Setup autostart
################# 
RCFILE=/etc/rc.tma1
RCTAB=rctma1
INITTAB=/etc/inittab
INITSAVE=$INITTAB.before.tma1

if [ ! -f $RCFILE ]
then
	set +e
	cat >> $RCFILE <<EOF
#!/bin/sh
#
#Start the Tivoli Management Agent
#
if [ -f $ETRC ]; then
    $ETRC start
fi
EOF


# If the creation of the /etc/rc.tma$1 file fails, then
# we need to exit, cleaning up any changes we might have
# made.
	if [ $? -ne 0 ]
	then
		rm -rf $RCFILE
		echo "Unable to install Tivoli Management Agent"
		exit 1
	fi

	chmod 0774 $RCFILE

	if [ $? -ne 0 ]
	then
		rm -rf $RCFILE
		echo "Unable to install Tivoli Management Agent"
		exit 1
	fi

	#  Okay - we've successfully added the rc startup file,
	mkitab "$RCTAB:2:wait:$RCFILE > /dev/console 2>&1 # Tivoli Management Agent"
	if [ $? -ne 0 ]
	then
		rmitab $RCTAB
		rm -rf $RCFILE
		cp $INITSAVE $INITTAB
		rm -rf $INITSAVE
		echo "Unable to modify /etc/inittab, removing Tivoli Management Agent installation"
		exit 2
	fi
else

echo "Auto start already configured as rc.tma1"
exit 1
fi

echo "Starting Tivoli Management Agent"

/opt/Tivoli/lcf/dat/1/lcfd.sh start -P 9191 -p $GWPORT -g "$GATEWAY"+"$GWPORT" -D bcast_disable=1 -D http_disable=2

exit 0
